import io from "socket.io-client";

import UserParams from './components/userParams/UserParams';
import BodyStatus from './components/bodyStatus/BodyStatus';

import './App.css';

const socket = io.connect("http://localhost:4200/", {
  reconnection: true
});

function App() {
  return (
    <div className="App">
      <UserParams socket={socket} />
      <BodyStatus socket={socket} />
    </div>
  );
}

export default App;
