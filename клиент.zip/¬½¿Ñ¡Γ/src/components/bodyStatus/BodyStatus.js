import { useState } from "react";

export default function BodyStatus(data) {
    const { socket } = data;

    const [index, setIndex] = useState('');
    const [status, setStatus] = useState('');
    const [recommendation, setRecommendation] = useState('');

    socket.on('showPlan', (data) => {
        console.log(data);
        setIndex(`Ваш индекс массы тела (ИМТ): ${data.index}`);
        setStatus(`Ваше состояние здоровья: ${data.plan.status}`)
        setRecommendation(`Рекомендация: ${data.plan.recommendation}`)
    });

    return (
        <div>
            <p>{index}</p>
            <p>{status}</p>
            <p>{recommendation}</p>
        </div>
    )
}