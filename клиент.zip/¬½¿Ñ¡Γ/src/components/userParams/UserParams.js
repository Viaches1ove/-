import { createRef, useState } from "react";
import './auth.css';

export default function UserParams(data) {

    const { socket } = data;

    const ageDistrict = createRef();
    const lowAgeButton = createRef();
    const heightAgeButton = createRef();

    const weightDistrict = createRef();
    const weightInput = createRef();

    const heightDistrict = createRef();
    const heightInput = createRef();

    const [age, setAge] = useState(null);

    function sendRecommendations(height, weight) {
        let canAuth = true;

        //Проверка на возраст
        if (!age) {
            canAuth = false;
            ageDistrict.current.className = 'errorDistrictName';
        } else {
            ageDistrict.current.className = 'districtName';
        }

        //Проверка на вес
        if (!weight) {
            canAuth = false;
            weightDistrict.current.className = 'errorDistrictName';
        } else {
            let isWeight = bodyParamsValidate(weight);
            if (isWeight)
                weightDistrict.current.className = 'districtName';
            else {
                canAuth = false;
                weightDistrict.current.className = 'errorDistrictName';
            }
        }

        //Проверка на рост
        if (!height) {
            canAuth = false;
            heightDistrict.current.className = 'errorDistrictName';
        } else {
            let isHeight = bodyParamsValidate(height);
            if (isHeight)
                heightDistrict.current.className = 'districtName';
            else {
                canAuth = false;
                heightDistrict.current.className = 'errorDistrictName';
            }
        }

        //запрос на получение рекомендаций
        if (canAuth) {
            socket.emit('getRecommendations', { age: age, height: height, weight: weight });
        }
    }

    function bodyParamsValidate(param) {
        if (param >= 0 && Number(param) == param) {
            return true;
        } else return false;
    }


    function chooseAge(age) {
        setAge(age);
        if (age === lowAgeButton.current.textContent) {
            lowAgeButton.current.className = 'activeAuthBtn';
            heightAgeButton.current.className = 'authBtn';
        } else {
            heightAgeButton.current.className = 'activeAuthBtn';
            lowAgeButton.current.className = 'authBtn';
        }
    }

    return (
        <div>
            <p className="title">Калькулятор индекса массы тела</p>
            <div>
                <p ref={weightDistrict} className="districtName">Вес</p>
                <input ref={weightInput} />
            </div>
            <div>
                <p ref={heightDistrict} className="districtName">Рост</p>
                <input ref={heightInput} />
            </div>
            <div>
                <p ref={ageDistrict} className="districtName">Возраст</p>
                <button className="authBtn" onClick={() => { chooseAge(lowAgeButton.current.textContent) }} ref={lowAgeButton}>18-25 лет</button>
                <button className="authBtn" onClick={() => { chooseAge(heightAgeButton.current.textContent) }} ref={heightAgeButton}>25+</button>
            </div>
            <div>
                <p className="districtName">Получить рекомендации</p>
                <button className="authBtn" onClick={() => { sendRecommendations(heightInput.current.value, weightInput.current.value) }}>Перейти</button>
            </div>

        </div>
    )


}