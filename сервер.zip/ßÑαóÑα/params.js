const PARAMS = {
    NAME: 'body Mass Index Calculator',
    PORT: 4200,
    DATABASE: {
        HOST: '',
        PORT: '',
        NAME: 'bodyMassIndexCalculator.db',
        USER: '',
        PASS: ''
    },
}
module.exports = PARAMS;