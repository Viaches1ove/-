const express = require('express');
const app = express();
const server = require('http').createServer(app);

const DB = require('./modules/db/DB');

const io = require('socket.io')(server, {
    cors: {
        origin: '*'
    }
});

const { PORT, DATABASE } = require('./params.js');


const db = new DB(DATABASE);

async function getPlan(age, height, weight) {
    let plan = null;

    let index = (weight / ((height / 100) * (height / 100))).toFixed(1);

    if (index < 17.5)
        plan = await db.getRecommendationsByStatus('Анорексия');


    if (index >= 17.5 && age === '18-25 лет')
        plan = await db.getRecommendationsByStatus('Ну ты и тупая жирная свинья');


    if (index >= 17.5 && age === '25+') {
        plan = await db.getRecommendationsByStatus('Ну ты и тупая жирная свинья в квадрате...Капец какой же ты жирный, пенсионер');
    }

    if (index)
        if (plan)
            return { index: index, plan: plan }

}


io.on('connection', (socket) => {

    socket.on('getRecommendations', async (data) => {
        const { age, height, weight } = data;
        const plan = await getPlan(age, height, weight);

        if (plan)
            socket.emit('showPlan', plan);
    });

});

app.use(express.static('public'));

server.listen(PORT);

function deinitModules() {
    db.destructor();
    setTimeout(() => process.exit(), 500);
}

process.on('SIGINT', deinitModules);
